# Load the necessary libraries
library(rlang)
library(e1071) # for SVM
library(caret) # for confusion matrix
library(rsample)
library(tidyr)
# Load the dataset
dataset <- read.csv("/home/kali/Desktop/Mini Project/FlowStatsfile.csv",nrows = 50000)
dataset
dataset$flow_id <- gsub("\\.", "", dataset$flow_id)
dataset$ip_src <- gsub("\\.", "", dataset$ip_src)
dataset$ip_dst <- gsub("\\.", "", dataset$ip_dst)

# Split the data into training and testing sets
set.seed(123)
split <- initial_split(dataset, prop = 0.7, strata = 'label')
train <- training(split)
test <- testing(split)

# Pre-process the data
scaler <- preProcess(train[, -ncol(train)], method = c("center", "scale"))
train_scaled <- predict(scaler, train[, -ncol(train)])
train[, -ncol(train)] <- train_scaled

test_scaled <- predict(scaler, test[, -ncol(test)])
test[, -ncol(test)] <- test_scaled

# Train the SVM model
svm_model <- svm(label ~ ., data = train, kernel = 'linear', cost = 1)

# Make predictions on the testing set
predictions <- predict(svm_model, test[, -ncol(test)])

# Evaluate the model's accuracy
conf_mat <- confusionMatrix(test$label, predictions)
conf_mat$table

acc <- conf_mat$overall['Accuracy']
cat("Success accuracy = ", round(acc*100, 2), "%\n")
fail <- 1 - acc
cat("Fail accuracy = ", round(fail*100, 2), "%\n")
cat("------------------------------------------------------------------------------\n")
# Load the necessary libraries
saveRDS(svm_model, "svm_model.rds")
